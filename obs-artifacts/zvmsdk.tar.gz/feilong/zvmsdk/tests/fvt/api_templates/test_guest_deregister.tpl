{
   "action": "deregister_vm",
}
