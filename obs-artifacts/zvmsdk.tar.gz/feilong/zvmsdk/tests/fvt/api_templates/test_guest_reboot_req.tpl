{
   "action": "reboot"
}
