{
   "action": "softstop"
}
