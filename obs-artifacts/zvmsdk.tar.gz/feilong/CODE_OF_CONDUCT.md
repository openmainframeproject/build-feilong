All participants agree to abide by the Code of Conduct of the Linux Foundation:
https://lfprojects.org/policies/code-of-conduct/

