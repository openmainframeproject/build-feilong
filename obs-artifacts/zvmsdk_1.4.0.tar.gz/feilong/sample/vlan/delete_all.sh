python del_vlan_v1s1.py
python del_vlan_v1s2.py
python del_vlan_v2s1.py
python del_vlan_v2s2.py

