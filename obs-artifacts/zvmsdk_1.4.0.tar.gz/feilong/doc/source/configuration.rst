..
 Copyright Contributors to the Feilong Project.
 SPDX-License-Identifier: CC-BY-4.0

.. _`configuration options`:

Configuration Options
*********************

.. literalinclude:: ./zvmsdk.conf.sample
